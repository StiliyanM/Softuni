﻿public class Writer : IWriter
{
    public void WriteLine(string message)
    {
        System.Console.WriteLine(message);
    }
}
