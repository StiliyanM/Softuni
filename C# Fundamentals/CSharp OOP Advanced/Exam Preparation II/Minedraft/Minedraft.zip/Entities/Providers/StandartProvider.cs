﻿public class StandartProvider : Provider
{
    public StandartProvider(int iD, double energyOutput) : base(iD, energyOutput)
    {
    }
}