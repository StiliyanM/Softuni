﻿namespace P07CustomList
{
    public enum Command
    {
        Add, Remove, Contains, Swap, Greater, Max, Min, Sort, Print, 
    }
}
