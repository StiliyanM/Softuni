﻿public class Easy : Mission
{
    public Easy(double scoreToComplete) : base(20, scoreToComplete, 30)
    {
    }

    public override string Name => "Suppression of civil rebellion";
}
