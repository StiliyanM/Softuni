﻿public class Medium : Mission
{
    public Medium(double scoreToComplete) : base(50, scoreToComplete, 50)
    {
    }

    public override string Name => "Capturing dangerous criminals";
}
