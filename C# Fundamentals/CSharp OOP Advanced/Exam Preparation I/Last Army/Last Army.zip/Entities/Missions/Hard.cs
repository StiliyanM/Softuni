﻿public class Hard : Mission
{
    public Hard(double scoreToComplete) : base(80, scoreToComplete, 70)
    {
    }

    public override string Name => "Disposal of terrorists";
}
