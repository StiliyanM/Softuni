﻿public class NightVision : Ammunition
{
    public NightVision(string name)
        : base(name, 0.8)
    {
    }
}
