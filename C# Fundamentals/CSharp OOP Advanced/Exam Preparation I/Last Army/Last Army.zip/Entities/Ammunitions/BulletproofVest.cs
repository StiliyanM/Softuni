﻿public class BulletproofVest : Ammunition
{
    public BulletproofVest(string name)
        : base(name, 3.4)
    {
    }
}
