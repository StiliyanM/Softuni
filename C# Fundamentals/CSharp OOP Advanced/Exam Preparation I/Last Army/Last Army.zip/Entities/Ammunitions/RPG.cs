﻿public class RPG : Ammunition
{
    public RPG(string name)
        : base(name, 17.1)
    {
    }
}
