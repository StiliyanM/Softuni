﻿public class Grenades : Ammunition
{
    public Grenades(string name)
        : base(name, 1.0)
    {
    }
}
