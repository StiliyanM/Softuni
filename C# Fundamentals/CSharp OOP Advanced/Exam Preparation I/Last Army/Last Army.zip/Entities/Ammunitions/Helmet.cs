﻿public class Helmet : Ammunition
{
    public Helmet(string name)
        : base(name, 2.3)
    {
    }
}
