﻿public class Shield : Ammunition
{
    public Shield(string name)
        : base(name, 3.7)
    {
    }
}
