﻿public class Gun : Ammunition
{
    public Gun(string name)
        : base(name, 1.4d)
    {
    }
}
