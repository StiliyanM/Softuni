﻿using System;
using System.Text;

namespace Last_Army
{
    class LastArmyMain
    {
        static void Main()
        {
            //var army = new Army();
            //var warehouse = new WareHouse();
            //var gameController = new GameController(army,warehouse);

            //var engine = new Engine(gameController);

            //engine.Run();
        }
    }
}