﻿using System;

public static class ConsoleReader
{
    public static string ReadLine()
    {
        return Console.ReadLine();
    }
}