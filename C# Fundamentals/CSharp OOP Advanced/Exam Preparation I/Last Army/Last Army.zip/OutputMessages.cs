﻿internal class OutputMessages
{
    internal static readonly string SoldierToString;
    internal static readonly string MissionDeclined;
    internal static readonly string MissionSuccessful;
    internal static readonly string MissionOnHold;
}