﻿using System;

namespace ReflectionLab
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Spy spy = new Spy();

            string result = spy.StealFieldInfo("System.Text.StringBuilder", "MaxChunkSize", "ThreadIDField");
            Console.WriteLine(result);
        }
    }
}
