﻿using System;

namespace P01Database
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
