﻿using System;

namespace P03IteratorTest
{
    class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
