﻿using System;

namespace P06Twitter
{
    class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
