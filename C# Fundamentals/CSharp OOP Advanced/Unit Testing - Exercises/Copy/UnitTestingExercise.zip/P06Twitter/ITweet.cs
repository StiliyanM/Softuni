﻿namespace P06Twitter
{
    public interface ITweet
    {
        string Message { get; }
    }
}
