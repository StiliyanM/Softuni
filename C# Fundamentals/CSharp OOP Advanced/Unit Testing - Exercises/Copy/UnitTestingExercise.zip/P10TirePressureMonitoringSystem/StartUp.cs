﻿namespace _10.TirePressureMonitoringSystem
{
    class StartUp
    {
        static void Main()
        {

        }
    }
}
