﻿using System;

namespace P05Integration
{
    class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
