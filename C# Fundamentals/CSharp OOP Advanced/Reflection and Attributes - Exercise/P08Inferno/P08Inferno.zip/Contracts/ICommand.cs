﻿namespace P08Inferno.Contracts
{
    public interface ICommand
    {
        void Execute();
    }
}