﻿namespace P08Inferno.Enums
{
    public enum Rarity
    {
        Common = 1,
        UnCommon = 2,
        Rare = 3,
        Epic = 5
    }
}