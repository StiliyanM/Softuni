﻿ namespace P01_HarvestingFields
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;

    public class HarvestingFieldsTest
    {
        public static void Main()
        {
            string command;

            FieldInfo[] allfields = GetAllFields();

            while ((command = Console.ReadLine()) != "HARVEST")
            {
                switch (command)
                {
                    case "private":
                        Print(allfields.Where(f => f.IsPrivate));
                        break;
                    case "protected":
                        Print(allfields.Where(f => !f.IsPrivate && !f.IsPublic));
                        break;
                    case "public":
                        Print(allfields.Where(f => f.IsPublic));
                        break;
                    case "all":
                        Print(allfields);
                        break;                    
                }
            }
        }

        private static void Print(IEnumerable<FieldInfo> fields)
        {
            foreach (var f in fields)
            {
                var accessModifier = f.Attributes.ToString() == "Family" ? "protected" : f.Attributes.ToString().ToLower();

                Console.WriteLine($"{accessModifier} {f.FieldType.Name} {f.Name}");
            }
        }

        private static FieldInfo[] GetAllFields()
        {
            var type = typeof(HarvestingFields);

            var fields = type.GetFields(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);

            return fields;
        }
    }
}
