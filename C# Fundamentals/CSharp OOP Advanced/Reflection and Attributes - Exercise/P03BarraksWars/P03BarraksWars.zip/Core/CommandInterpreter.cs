﻿using System;
using System.Linq;
using System.Reflection;
using P03BarracksFactory.Contracts;

namespace P03BarracksFactory.Core
{
    internal class CommandInterpreter
    {
        public CommandInterpreter()
        {
        }

        public string InterpredCommand(string[] data, string commandName, IRepository repository, IUnitFactory unitFactory)
        {
            var assembly = Assembly.GetExecutingAssembly();

            var type = assembly.GetTypes().FirstOrDefault(t => t.Name.ToLower() == commandName + "command");

            if(type == null)
            {
                throw new InvalidOperationException("Invalid command!");
            }
            var instance = Activator.CreateInstance(type, new object[] { data, repository, unitFactory });

            var method = type.GetMethod("Execute");

            return (string)method.Invoke(instance, new object[] { });
        }
    }
}