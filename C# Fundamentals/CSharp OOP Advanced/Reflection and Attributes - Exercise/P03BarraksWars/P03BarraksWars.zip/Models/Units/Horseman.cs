﻿namespace P03BarracksFactory.Models.Units
{
    public class Horseman : Unit
    {
        public Horseman() : base(50, 10)
        {
        }
    }
}
