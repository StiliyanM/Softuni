﻿namespace P03BarracksFactory.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
