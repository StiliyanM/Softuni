﻿namespace P03BarracksFactory.Contracts
{
    public interface IExecutable
    {
        string Execute();
    }
}
