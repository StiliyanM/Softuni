﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P09CollectionHierarchy.Contracts
{
    public interface IMyList<T> : IAddCollection<T>, IAddRemoveCollection<T>
    {
        int Used { get; }
    }
}
