﻿namespace P09CollectionHierarchy
{
    using System.Text;

    using Models;

    public class CollectionManipulator
    {
        private StringBuilder resultBuilder = new StringBuilder();

        public void FillCollection<T>(string[] data, AddCollection<string> collection)
        {
            foreach (var item in data)
            {
                var index = collection.Add(item);

                resultBuilder.Append($"{index} ");
            }

            resultBuilder = resultBuilder
                .Remove(this.resultBuilder.Length - 1, 1)
                .AppendLine();
        }

        public void Remove<T>(int numberOfOperations, AddRemoveCollection<T> collection)
        {
            for (int i = 0; i < numberOfOperations; i++)
            {
                var element = collection.Remove();

                resultBuilder.Append($"{element} ");
            }

            resultBuilder = resultBuilder
                .Remove(this.resultBuilder.Length - 1, 1)
                .AppendLine();
        }

        public string GetOperationsInfo()
        {
            return this.resultBuilder.ToString().TrimEnd();
        }
    }
}
