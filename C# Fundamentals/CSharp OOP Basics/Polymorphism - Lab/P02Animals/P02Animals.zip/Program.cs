﻿using System;

namespace P02Animals
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
