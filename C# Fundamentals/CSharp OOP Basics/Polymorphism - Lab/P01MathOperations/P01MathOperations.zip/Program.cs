﻿using System;

namespace P01MathOperations
{
    class Program
    {
        public static void Main()
        {
        }

    }
}
