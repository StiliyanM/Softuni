﻿using System;

namespace P03Shapes
{
    class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
