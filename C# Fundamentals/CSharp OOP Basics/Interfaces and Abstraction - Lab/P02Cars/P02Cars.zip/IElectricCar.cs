﻿public interface IElectricCar
{
    int Battery { get; set; }
}
